/**
* virtApp Module
* main App module
*
*/
angular.module('virtApp', ['dashboardController']);